setwd("/Volumes/Sanchez/My CMSA Camp/Soccer-master")
soccer <- read.csv("cleaned_data.csv") #just passing data 
soccer <- read.csv("7-13Soccer.csv")

library(tidyverse)

#all data 
data_path <- '/Volumes/Sanchez/My CMSA CAMP/open-data-master/data/events'

files <- dir(path = data_path,pattern = "*.json")



data <- tibble(match = files) %>% # create a data frame
  # holding the file names
  mutate(data = map(files,function(x) jsonlite::fromJSON(txt = file.path(data_path, x) , flatten = TRUE) ) # a new data column
  )

data<-data %>% unnest()


data %>% filter(type.name == "Pass" | type.name == "Shot") -> passes_and_shots

#now we can add anything we want to the exisiting df we cleaned. 

soccer %>% group_by(match, possession, type.name) %>% mutate(new.length = rev(seq(1:n()))) -> soccer


View(head(data, n = 40L))



#Exploratory Data Analysis

#1 first model -- expected goals in 'box'
#2 regression


#Expected Goals (from Shot) by position on the Field
#only shots

shots <- soccer %>% filter(type.name == "Shot")

ggplot(shots, aes(x = x.location, y = y.location, col = shot.statsbomb_xg)) + geom_point() + theme_bw() +
  labs(x = "Width", y = "Length", title = "Expected Goals by Location on the Pitch")

goalkeepers <- 

install.packages('mgcv')

library(mgcv)
#Split into passes only since we have distributed the xG. Do not need shots. Then run 

soccer %>% filter(., type.name == "Pass") -> passes

model1 <- gam(shot.statsbomb_xg ~ s(x.location,y.location), data = passes)

#run as Bam 
model1b <- bam(shot.statsbomb_xg ~ s(x.location,y.location), data = passes)

#run as before but now including length value

model2 <- gam(shot.statsbomb_xg ~ s(x.location,y.location) + s(length), data = passes)


summary(model1)
plot(model1, scheme = 2)

#run model with just passes that are successful
model1 <- gam(shot.statsbomb_xg ~ s(x.location,y.location), data = successes)
summary(model1b)
print.gam(model1b)

rm(model1)
#ditrib
hist(successes$shot.statsbomb_xg)

nrow(passes)
#add end location
data %>% filter(type.name == "Pass") %>% filter() -> prelim
passes$end.location<- prelim$pass.end_location

endloc <- unlist(passes$end.location)

endloc.df <- as.data.frame(endloc)
endloc.df$xory <- rep(1:2, times = 478014/2)

endloc.df %>% filter(endloc.df$xory == 1)-> x
endloc.df %>% filter(endloc.df$xory == 2)-> y

passes$x.end.location <- x$endloc
passes$y.end.location <- y$endloc


## add end location (to original data set (just passes and shots)) and retrieving first two coordinates

true_false<- unlist(map(.x =passes_and_shots$pass.end_location,.f = is.null ))
true_false

passes_and_shots$end.location <- ifelse(true_false, passes_and_shots$shot.end_location, passes_and_shots$pass.end_location)

View(head(passes_and_shots, n = 40L))

passes_and_shots$end.x.location <- 1:245863
passes_and_shots$end.y.location <- 1:245863

get_first <-function(list_loc) {
  return(list_loc[1])
}

get_second <-function(list_loc) {
  return(list_loc[2])
}

passes_and_shots$end.x.location <- map(.x = passes_and_shots$end.location, .f = get_first)
passes_and_shots$end.y.location <- map(.x = passes_and_shots$end.location, .f = get_second)

soccer$end.x.location <- unlist(passes_and_shots$end.x.location)
soccer$end.y.location <- unlist(passes_and_shots$end.y.location)

within(soccer, rm(end.location)) -> soccer

soccer<- as.data.frame(soccer)
map(soccer,typeof)

write.csv(soccer,file = "SoccerVis.csv")

View(head(soccer))
first




#add successes
passes %>% filter(shot.statsbomb_xg != 0) -> successes

#add index = 'eventid' which will be unique for one match.

View(head(successes))

View(head(soccer, n = 40))


model4 <- gam(shot.statsbomb_xg ~ s(x.location,y.location,x.end.location,y.end.location), data = successes)
gam.check(model4)
plot(model4, scheme = 2)

first

###################### scale coordinates for StatsBomb
first.match %>% mutate(x.location = x.location*1.2, y.location = y.location*.8, end.x.location = end.x.location*1.2,
                       end.y.location = end.y.location*.8)


### make soccer animations slower
first.match$X = first.match$X*(1/100)

animate(first, nframes = 400, duration = 20, fps = 20, end_pause = 5, rewind = FALSE)



first + transition_st(possession) + labs(title = "EventID: {frame_time}") +
  shadow_wake(wake_length = 0.01, alpha = TRUE)

animate(first2, nframes = nrow(first.match), duration = 20, fps = 1, end_pause = 5, rewind = FALSE)
warnings()
?animate
data$shot.outcome.name

